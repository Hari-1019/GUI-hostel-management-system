﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void Booking_Load(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                       Initial Catalog=hosteldb;
                       Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "SELECT roomtype FROM roomtypetable";
            SqlCommand com = new SqlCommand(sql, con);

            //creating a reader 
            SqlDataReader dr1 = com.ExecuteReader();


            // Add items to the ComboBox
            while (dr1.Read())
            {
                comboBox1_roomtype.Items.Add(dr1.GetValue(0).ToString());
            }


            //disconnecting connection 
            con.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "INSERT INTO bookingtable (guestname, email, roomtype, guests, arrival, departure) VALUES (@guestname, @guestemail, @roomtype, @guests, @arrival, @departure)";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@guestname", this.txt_guestname.Text);
                        com.Parameters.AddWithValue("@guestemail", this.txt_email.Text);
                        com.Parameters.AddWithValue("@roomtype", this.comboBox1_roomtype.Text);
                        com.Parameters.AddWithValue("@guests", this.txt_guest.Text);
                        com.Parameters.AddWithValue("@arrival", this.dateTimePicker1_arrival.Value); 
                        com.Parameters.AddWithValue("@departure", this.dateTimePicker2_departure.Value); 

                        com.ExecuteNonQuery();

                        MessageBox.Show("Booking successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("plese enter the details in related field : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    con.Close();
                }
            }


        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_bookid.Text))
            {
                MessageBox.Show("Please enter a valid guest ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853;
                        Initial Catalog=hosteldb;
                        Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "DELETE FROM bookingtable WHERE bookingid = @bookingid";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@bookingid", txt_bookid.Text);

                        int rowsAffected = com.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No record found with the given ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                        Initial Catalog=hosteldb;
                        Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            // Corrected SQL query by removing the extra comma
            string sql = "SELECT guestname, email, roomtype, guests FROM bookingtable WHERE bookingid=@bookingid";
            SqlCommand com = new SqlCommand(sql, con);

            // Adding the bookingid parameter
            com.Parameters.AddWithValue("@bookingid", this.txt_bookid.Text);
            SqlDataReader cd = com.ExecuteReader();

            if (cd.Read())
            {
                // Assigning values 
                this.txt_guestname.Text = cd.GetValue(0).ToString(); 
                this.txt_email.Text = cd.GetValue(1).ToString(); 
                this.comboBox1_roomtype.Text = cd.GetValue(2).ToString(); 
                this.txt_guest.Text = cd.GetValue(3).ToString(); 
            }
            else
            {
                MessageBox.Show("No records found with the given Booking ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Closing the SqlDataReader
            cd.Close();
            // Closing the connection
            con.Close();



        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            bookingview br= new bookingview();
            br.Show();


        }

        private void btn_clear_Click_1(object sender, EventArgs e)
        {
            this.txt_guestname.Clear();
            this.txt_email.Clear();
            
            this.txt_guest.Clear();

            
        }
    }
}
    

