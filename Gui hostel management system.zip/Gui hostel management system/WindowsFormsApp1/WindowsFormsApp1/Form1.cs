﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login_Form1 : Form
    {
        public Login_Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            //connection to the data base 
            {
                string cs = @"Data Source=DESKTOP-P5ME853;
                       Initial Catalog=hosteldb;
                       Integrated Security=true";

                SqlConnection conn = new SqlConnection(cs);
                conn.Open();

                string username = this.txt_username.Text;
                string password = this.txt_password.Text;


                string sql = "SELECT username, password FROM logintable WHERE username = @username AND password = @password";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("login sucessfull");
                    Main mn = new Main();
                    mn.Show();
                }
                else
                {
                    MessageBox.Show("invalid username or password");
                }

                conn.Close();
            }
        }

        private void Login_Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_password.Clear();
            txt_username.Clear();
        }
    }
}
