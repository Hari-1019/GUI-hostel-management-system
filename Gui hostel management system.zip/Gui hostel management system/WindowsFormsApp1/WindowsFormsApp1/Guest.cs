﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Guest : Form
    {
        public Guest()
        {
            InitializeComponent();
        }

        private void Guest_Load(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                       Initial Catalog=hosteldb;
                       Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            //creating command 
            string sql = "SELECT MAX(guestid) FROM guest_table";
            SqlCommand cmd = new SqlCommand(sql, con);

            //creating a reader 
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                if (dr.GetValue(0).ToString() == "")
                {
                    this.txt_guestid.Text = "1";
                }
                else
                {
                    this.txt_guestid.Text = (Convert.ToInt32(dr.GetValue(0).ToString()) + 1).ToString();
                }


            }
            else
            {
                this.txt_guestid.Text = "1";
            }

            con.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "INSERT INTO guest_table(guestname,phonenumber,address) VALUES(@guestname,@phonenumber,@address)";
            SqlCommand com= new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@guestname", txt_guestname.Text);
            com.Parameters.AddWithValue("@phonenumber", txt_phonenumber.Text);
            com.Parameters.AddWithValue("@address", txt_address.Text);
            if (this.txt_phonenumber.Text.Length != 10)
            {
                // Set the error on the txt_phonenumber control
                errorProvider1.SetError(this.txt_phonenumber, "Phone number should 10 digits.");
            }
            
            
                

            
            else
            {
                com.ExecuteNonQuery();
                MessageBox.Show("saved succesfully");
            }
            

            

            con.Close();
            

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "SELECT *FROM guest_table";
            SqlCommand com = new SqlCommand(sql, con);

            SqlDataAdapter da= new SqlDataAdapter(com);
            DataTable dt= new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
            this.txt_guestname.Clear();
            this.txt_phonenumber.Clear();
            this.txt_address.Clear();
            this.txt_guestid.Clear();



        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_guestid.Text))
            {
                MessageBox.Show("Please enter a valid guest ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "DELETE FROM guest_table WHERE guestid = @guestid";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@guestid", txt_guestid.Text);

                        int rowsAffected = com.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No record found with the given ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void txt_guestname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
