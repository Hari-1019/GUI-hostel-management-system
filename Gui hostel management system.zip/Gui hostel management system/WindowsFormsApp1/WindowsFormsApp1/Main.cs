﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void bookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Booking br = new Booking();
            br.Show();
        }

        private void guestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Guest gt = new Guest();
            gt.Show();

        }

        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            staff st=new staff();
            st.Show();
        }

        private void paymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            payment pay=new payment();
            pay.Show();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            
            List<Form> openForms = new List<Form>();

            
            foreach (Form form in Application.OpenForms)
            {
                if (form.Name != "Login_Form1") 
                {
                    openForms.Add(form);
                }
            }

            
            foreach (Form form in openForms)
            {
                form.Close();
            }

            
            



        }

        private void roomToolStripMenuItem_Click(object sender, EventArgs e)
        {
           room room = new room();
            room.Show();


        }
    }
}
