﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class bookingview : Form
    {
        public bookingview()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void bookingview_Load(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            SqlConnection con=new SqlConnection(cs);
            con.Open();
            string sql = "SELECT * FROM bookingtable";
            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;

            con.Close();

        }
    }
}
