﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class payment : Form
    {
        public payment()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void payment_Load(object sender, EventArgs e)
        {



        }

        private void btn_apply_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
             Initial Catalog=hosteldb;
             Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    //creating a command 
                    string sql = "SELECT guestname, roomtype FROM bookingtable WHERE bookingid=@bookingid";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@bookingid", this.txt_bookid.Text);

                        using (SqlDataReader cd = com.ExecuteReader())
                        {
                            if (cd.Read())
                            {
                                this.txt_guestname.Text = cd.GetValue(0).ToString(); // 0 is the index for guestname
                                this.txt_roomtype.Text = cd.GetValue(1).ToString();  // 1 is the index for roomtype
                            }
                            else
                            {
                                MessageBox.Show("No records found with the given Booking ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    con.Close();
                }


            }

        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            //calculate
            decimal days = numericUpDown1.Value; // Get the value from NumericUpDown as decimal
            decimal roomPrice;

            decimal.TryParse(txt_roomprice.Text, out roomPrice);
            decimal total = days * roomPrice; // Calculate the total amount
            txt_totalpayment.Text = total.ToString();




        }

        private void btn_add_Click(object sender, EventArgs e)
        {

            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    string sql = "SELECT * FROM paymenttable";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();

                        da.Fill(dt);

                        // Bind the DataTable to the DataGridView
                        dataGridView1.DataSource = dt;

                        
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("SQL error: " + ex.Message, "SQL Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "INSERT INTO paymenttable (bookingid, guestname, roomtype, days, totalamount) VALUES (@bookingid, @guestname, @roomtype, @days, @totalamount)";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@bookingid", txt_bookid.Text);
                        cmd.Parameters.AddWithValue("@guestname", txt_guestname.Text);
                        cmd.Parameters.AddWithValue("@roomtype", txt_roomtype.Text);
                        cmd.Parameters.AddWithValue("@days", numericUpDown1.Value);
                        cmd.Parameters.AddWithValue("@totalamount", decimal.Parse(txt_totalpayment.Text));

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data saved and added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_printreport_Click(object sender, EventArgs e)
        {
            paymentreport pt = new paymentreport();
            pt.Show();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_paymentid.Text))
            {
                MessageBox.Show("Please enter a valid guest ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853;
                        Initial Catalog=hosteldb;
                        Integrated Security=true";
            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "DELETE FROM paymenttable WHERE paymentid = @paymentid";
            SqlCommand com = new SqlCommand(sql, con);

            com.Parameters.AddWithValue("@paymentid", txt_paymentid.Text);

            int rowsAffected = com.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No record found with the given ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}




            

