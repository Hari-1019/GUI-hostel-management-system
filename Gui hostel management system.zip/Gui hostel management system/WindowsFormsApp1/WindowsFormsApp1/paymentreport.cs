﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class paymentreport : Form
    {
        public paymentreport()
        {
            InitializeComponent();
        }

        private void paymentreport_Load(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                          Initial Catalog=hosteldb;
                          Integrated Security=true";
            SqlConnection con=new SqlConnection(cs);
            con.Open();

            string sql = "SELECT* FROM paymenttable";
            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataAdapter ad=new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            ad.Fill(ds);

            ReportDocument rpt = new ReportDocument();
            rpt.Load(@"C:\Users\USER\Desktop\Gui hostel management system\WindowsFormsApp1\WindowsFormsApp1\CrystalReport1.rpt"); // Ensure the path is correct
            rpt.SetDataSource(ds);

            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();



        }
    }
}
