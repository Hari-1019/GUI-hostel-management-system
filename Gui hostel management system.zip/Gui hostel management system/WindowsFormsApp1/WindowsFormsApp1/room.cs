﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class room : Form
    {
        public room()
        {
            InitializeComponent();
        }

        private void room_Load(object sender, EventArgs e)
        {
              string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

                SqlConnection con = new SqlConnection(cs);
                con.Open();

                string sql = "SELECT *FROM roomtable";
                SqlCommand cmd = new SqlCommand(sql, con);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                con.Close();
            


            string css = @"Data Source=DESKTOP-P5ME853;
                       Initial Catalog=hosteldb;
                       Integrated Security=true";

            SqlConnection con1 = new SqlConnection(css);
            con1.Open();

            string sql1 = "SELECT roomtype FROM roomtypetable";
            SqlCommand com = new SqlCommand(sql1, con1);

            //creating a reader 
            SqlDataReader dr1 = com.ExecuteReader();


            // Add items to the ComboBox
            while (dr1.Read())
            {
                comboBox1roomtype.Items.Add(dr1.GetValue(0).ToString());
            }


            //disconnecting connection 
            con1.Close();


            LoadAvailableRooms();
            LoadReservedRooms();

            LoadAvailableRooms1();
            LoadReservedRooms1();
        }

        private void btn_reserve_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    // Insert into reserveroomtable
                    string sqlInsert = "INSERT INTO reserveroomtable (bookingid, roomtype, roomnumber) VALUES (@bookingid, @roomtype, @roomnumber)";
                    using (SqlCommand cmd = new SqlCommand(sqlInsert, con))
                    {
                        cmd.Parameters.AddWithValue("@bookingid", txt_bookingid.Text);
                        cmd.Parameters.AddWithValue("@roomtype", comboBox1roomtype.Text);
                        cmd.Parameters.AddWithValue("@roomnumber", txt_roomnumber.Text);
                        cmd.ExecuteNonQuery();
                    }

                    // Delete the reserved room from roomtable
                    string sqlDelete = "DELETE FROM roomtable WHERE roomtype = @roomtype AND roomnumber = @roomnumber";
                    using (SqlCommand cmd1 = new SqlCommand(sqlDelete, con))
                    {
                        cmd1.Parameters.AddWithValue("@roomtype", comboBox1roomtype.Text);
                        cmd1.Parameters.AddWithValue("@roomnumber", txt_roomnumber.Text);
                        cmd1.ExecuteNonQuery();
                    }

                    // Decrement the roomcount for the specific roomtype
                    string sqlUpdate = "UPDATE roomtable SET roomcount = roomcount - 1 WHERE roomtype = @roomtype";
                    using (SqlCommand cmd2 = new SqlCommand(sqlUpdate, con))
                    {
                        cmd2.Parameters.AddWithValue("@roomtype", comboBox1roomtype.Text);
                        cmd2.ExecuteNonQuery();
                    }

                    MessageBox.Show("Room reserved successfully.");

                    // Reload data into dataGridView1 and dataGridView2
                    LoadAvailableRooms();
                    LoadReservedRooms();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txt_bookingid.Clear();
            txt_roomnumber.Clear();

        }

        private void LoadReservedRooms()
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    string sql = "SELECT * FROM reserveroomtable";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        SqlDataAdapter ad = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        ad.Fill(dt);
                        dataGridView2.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadAvailableRooms()
        {
            string cs = @"Data Source=DESKTOP-P5ME853;
                  Initial Catalog=hosteldb;
                  Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    string sql = "SELECT roomtype, roomnumber, roomcount FROM roomtable ORDER BY roomnumber";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string roomNumberToDelete = txt_deleteroomnumber.Text;
            if (string.IsNullOrWhiteSpace(roomNumberToDelete))
            {
                MessageBox.Show("Please enter a valid room number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853;Initial Catalog=hosteldb;Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    // Retrieve the roomtype for the room to be deleted
                    string sqlGetRoomType = "SELECT roomtype FROM reserveroomtable WHERE roomnumber = @roomnumber";
                    string roomType = string.Empty;
                    using (SqlCommand cmdGetRoomType = new SqlCommand(sqlGetRoomType, con))
                    {
                        cmdGetRoomType.Parameters.AddWithValue("@roomnumber", roomNumberToDelete);
                        SqlDataReader reader = cmdGetRoomType.ExecuteReader();
                        if (reader.Read())
                        {
                            roomType = reader["roomtype"].ToString();
                        }
                        reader.Close();
                    }

                    if (string.IsNullOrEmpty(roomType))
                    {
                        MessageBox.Show("Room number not found in reserved rooms.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Delete the room from reserveroomtable
                    string sqlDelete = "DELETE FROM reserveroomtable WHERE roomnumber = @roomnumber";
                    using (SqlCommand cmdDelete = new SqlCommand(sqlDelete, con))
                    {
                        cmdDelete.Parameters.AddWithValue("@roomnumber", roomNumberToDelete);
                        cmdDelete.ExecuteNonQuery();
                    }

                    // Update roomtable to add the room back
                    string sqlUpdate = @"
                IF EXISTS (SELECT 1 FROM roomtable WHERE roomtype = @roomtype AND roomnumber = @roomnumber)
                BEGIN
                    UPDATE roomtable 
                    SET roomcount = roomcount + 1 
                    WHERE roomtype = @roomtype AND roomnumber = @roomnumber;
                END
                ELSE
                BEGIN
                    INSERT INTO roomtable (roomtype, roomnumber, roomcount) 
                    VALUES (@roomtype, @roomnumber, 1);
                END";
                    using (SqlCommand cmdUpdate = new SqlCommand(sqlUpdate, con))
                    {
                        cmdUpdate.Parameters.AddWithValue("@roomtype", roomType);
                        cmdUpdate.Parameters.AddWithValue("@roomnumber", roomNumberToDelete);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    MessageBox.Show("Room reservation deleted and room table updated successfully.");

                    // Reload data into dataGridView1 and dataGridView2
                    LoadAvailableRooms();
                    LoadReservedRooms();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txt_deleteroomnumber.Clear();
        }

        private void LoadReservedRooms1()
        {
            string cs = @"Data Source=DESKTOP-P5ME853;Initial Catalog=hosteldb;Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    string sql = "SELECT * FROM reserveroomtable";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        SqlDataAdapter ad = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        ad.Fill(dt);
                        dataGridView2.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadAvailableRooms1()
        {
            string cs = @"Data Source=DESKTOP-P5ME853;Initial Catalog=hosteldb;Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();
                    string sql = @"
                SELECT roomtype, roomnumber, roomcount 
                FROM roomtable 
                ORDER BY roomtype, roomnumber";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
    }




