﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class staff : Form
    {
        public staff()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "INSERT INTO staff_table(staffid,name,phone) VALUES(@staffid,@name,@phone)";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@staffid", txt_staffid.Text);
            com.Parameters.AddWithValue("@name", txt_name.Text);
            com.Parameters.AddWithValue("@phone", txt_phone.Text);


            com.ExecuteNonQuery();
            MessageBox.Show("saved succesfully");

            con.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            SqlConnection con = new SqlConnection(cs);
            con.Open();

            string sql = "SELECT *FROM staff_table";
            SqlCommand com = new SqlCommand(sql, con);

            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();

            this.txt_staffid.Clear();
            this.txt_name.Clear();
            this.txt_phone.Clear();


        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_staffid.Text))
            {
                MessageBox.Show("Please enter a valid guest ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "DELETE FROM staff_table WHERE staffid = @staffid";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@staffid", txt_staffid.Text);

                        int rowsAffected = com.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No record found with the given ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_staffid.Text))
            {
                MessageBox.Show("Please enter a valid staff ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cs = @"Data Source=DESKTOP-P5ME853; Initial Catalog=hosteldb; Integrated Security=true";

            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    con.Open();

                    string sql = "SELECT * FROM staff_table WHERE staffid = @staffid";
                    using (SqlCommand com = new SqlCommand(sql, con))
                    {
                        com.Parameters.AddWithValue("@staffid", txt_staffid.Text);

                        SqlDataAdapter da = new SqlDataAdapter(com);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = dt;
                        }
                        else
                        {
                            MessageBox.Show("No record found with the given ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dataGridView1.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
    

